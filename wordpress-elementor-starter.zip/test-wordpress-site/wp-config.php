<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'test-wordpress-site');

/** MySQL database username */
define('DB_USER', 'root');

/** MySQL database password */
define('DB_PASSWORD', '');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8mb4');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         ';J<>zsJGBD,G$1pBc>Z:QAU;O5?i@i9f3N/.|&Yy1YFN;c4%aAO0PxF%t/K$6<x(');
define('SECURE_AUTH_KEY',  '# cwQ7VxwVG>o(d/w2Z/l_qG>1fy7n1xHWe.L_4ZWSYHdbXN1-9f8YKe2]%F hYP');
define('LOGGED_IN_KEY',    '7EAx<w]vG[$q}C2x%]X*:o9]8s90!dtLjN9^,)iXr=hz}L4V?VsF2%!W)AGNr7J/');
define('NONCE_KEY',        'VH;mA.b&cWfjL&,}[PP>-a:7&Q{&r[|RUU,NghA-JdpII P+BM@qMjlG{/N-*uZ#');
define('AUTH_SALT',        'S; 5]f;%c,KP@^_@%;*WRu+oA}_kM1.mb~kVLXj0a{FOk^}`>`7)T|?uylZ-NJg.');
define('SECURE_AUTH_SALT', 'oF)$LDHg-iE5fTE~=[HdI?6(h-: `[{b;_w3O*6C_yMh7|wr94 ll0v nrJPE`gV');
define('LOGGED_IN_SALT',   'HcD>@P?vJy~]i?Zp-G7!kG @]=9.O8(]z|TPB=wuP6^8X$QT88!k0g7^dz#;qU=l');
define('NONCE_SALT',       'yvmisS&6oTI^BsmL}vGN-<GCh][5O]iMDw<tBaYs?>WyHR)=-S((uS3S59F^v{11');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
